import React, { useState } from "react";
import { View, Text, Button, Image, ActivityIndicator } from "react-native";
import * as ImagePicker from "expo-image-picker";

const BASE_URL = "http://YOUR_IP:8000";

export default function App() {
  const [image, setImage] = useState(null);
  const [pgn, setPgn] = useState("");
  const [loading, setLoading] = useState(false);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setImage(uri);
      sendToBackend(uri);
    }
  };

  const sendToBackend = async (uri) => {
    setLoading(true);
    setPgn("");

    const formData = new FormData();
    formData.append("file", {
      uri,
      name: "image.jpg",
      type: "image/jpeg",
    });

    try {
      const res = await fetch(`${BASE_URL}/extract`, {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      setPgn(data.pgn);
    } catch (e) {
      setPgn("Backend error");
    }

    setLoading(false);
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Tempo</Text>

      <Button title="Upload" onPress={pickImage} />

      {image && (
        <Image source={{ uri: image }} style={{ width: 200, height: 200 }} />
      )}

      {loading && <ActivityIndicator />}

      {pgn !== "" && <Text>{pgn}</Text>}
    </View>
  );
}