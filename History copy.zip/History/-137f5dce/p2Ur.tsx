/** @jsxImportSource react */
import React, { useState } from "react";
import { View, Text, Button, Image, ActivityIndicator } from "react-native";
import * as ImagePicker from "expo-image-picker";

const BASE_URL = "http://YOUR_IP:8000";

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [pgn, setPgn] = useState("");
  const [loading, setLoading] = useState(false);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setImage(uri);
      sendToBackend(uri);
    }
  };

  const sendToBackend = async (uri: string) => {
    try {
      setLoading(true);
      setPgn("");

      const formData = new FormData();

      formData.append("file", {
        uri,
        name: "image.jpg",
        type: "image/jpeg",
      } as any);

      const res = await fetch(`${BASE_URL}/extract`, {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      setPgn(data.pgn);
    } catch (e) {
      setPgn("Error connecting backend");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text style={{ fontSize: 22, marginBottom: 20 }}>Tempo</Text>

      <Button title="Upload Image" onPress={pickImage} />

      {image && (
        <Image
          source={{ uri: image }}
          style={{ width: 200, height: 200, marginTop: 20 }}
        />
      )}

      {loading && <ActivityIndicator size="large" />}

      {pgn !== "" && (
        <Text style={{ marginTop: 20 }}>{pgn}</Text>
      )}
    </View>
  );
}