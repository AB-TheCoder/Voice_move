import React, { useState } from 'react';
import { View, Text, Button, Image, Alert, ScrollView } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [pgn, setPgn] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permission.status !== 'granted') {
      Alert.alert('Permission required', 'Please allow access to your photos.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      quality: 0.8,
      allowsEditing: false,
    });

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setImage(uri);
      await sendToBackend(uri);
    }
  };

  const sendToBackend = async (uri: string) => {
    try {
      setLoading(true);
      setPgn("");

      // IMPORTANT: replace with your computer's local IP
      const BASE_URL = "http://192.168.29.28:8000";

      const formData = new FormData();
      formData.append('file', {
        uri: uri,
        name: 'image.jpg',
        type: 'image/jpeg',
      } as any);

      const controller = new AbortController();
      setTimeout(() => controller.abort(), 10000);

      const res = await fetch(`${BASE_URL}/extract`, {
        method: 'POST',
        body: formData,
        signal: controller.signal,
      });

      if (!res.ok) {
        throw new Error(`Server error: ${res.status}`);
      }

      const data = await res.json();
      setPgn(data.pgn || 'No PGN returned');
    } catch (err: any) {
      console.log(err);
      Alert.alert('Error', err.message || 'Failed to fetch PGN');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
      <Text style={{ fontSize: 28, fontWeight: '600', marginBottom: 20 }}>Tempo</Text>

      <Button title="Upload Scoresheet" onPress={pickImage} />

      {image && (
        <Image
          source={{ uri: image }}
          style={{ width: 240, height: 240, marginTop: 20, borderRadius: 12 }}
        />
      )}

      {loading && (
        <Text style={{ marginTop: 20 }}>Processing...</Text>
      )}

      {pgn !== '' && (
        <View style={{ marginTop: 20 }}>
          <Text style={{ fontWeight: '600', marginBottom: 8 }}>PGN Output:</Text>
          <Text selectable>{pgn}</Text>
        </View>
      )}
    </ScrollView>
  );
}
