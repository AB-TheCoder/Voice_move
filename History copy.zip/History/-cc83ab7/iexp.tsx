import React, { useEffect, useState } from "react";
import { View, Text, Button, Image, Alert, ActivityIndicator } from "react-native";
import * as ImagePicker from "expo-image-picker";

const BASE_URL = "http://YOUR_MAC_IP:8000"; // replace with your actual IP

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [pgn, setPgn] = useState<string>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("Permission required", "Allow media library access to pick images.");
      }
    })();
  }, []);

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: false,
        quality: 1,
      });

      if (!result.canceled) {
        const uri = result.assets[0].uri;
        setImage(uri);
        await sendToBackend(uri);
      }
    } catch (err) {
      console.log("Image picker error:", err);
      Alert.alert("Error", "Failed to pick image");
    }
  };

  const sendToBackend = async (uri: string) => {
    try {
      setLoading(true);
      setPgn("");

      console.log("Sending image:", uri);

      const formData = new FormData();

      formData.append("file", {
        uri,
        name: "image.jpg",
        type: "image/jpeg",
      } as any);

      const response = await fetch(`${BASE_URL}/extract`, {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      console.log("Response:", data);

      setPgn(data.pgn || "No PGN returned");
    } catch (error) {
      console.log("Backend error:", error);
      Alert.alert("Error", "Failed to send image to server");
    } finally {
      setLoading(false);
    }
  };

return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 20 }}>
      <Text style={{ fontSize: 20, marginBottom: 20 }}>Tempo</Text>

      <Button title="Upload Scoresheet" onPress={pickImage} />

      {image && (
        <Image
          source={{ uri: image }}
          style={{ width: 200, height: 200, marginTop: 20 }}
        />
      )}

      {loading && <ActivityIndicator size="large" style={{ marginTop: 20 }} />}

      {pgn !== "" && (
        <Text style={{ marginTop: 20, fontSize: 16 }}>
          PGN: {pgn}
        </Text>
      )}
    </View>
  );
}