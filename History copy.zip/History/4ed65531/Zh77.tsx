"use client";
import { useEffect, useState } from "react";

export default function Home() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setLoaded(true);
  }, []);

  const pillars = [
    {
      title: "Capture Every Game Properly",
      text:
        "Tempo gives players one place to preserve their games. Upload scoresheets, enter moves manually, or use quick recording tools after a round. Instead of losing valuable tournament data, every game becomes something you can revisit and learn from later.",
    },
    {
      title: "Review What Actually Mattered",
      text:
        "Most players remember only the final blunder. Tempo helps you review the full story of a game: opening choices, missed opportunities, turning points, time-pressure decisions, and patterns that keep appearing.",
    },
    {
      title: "Train From Your Own Weaknesses",
      text:
        "Generic puzzles have value, but targeted training is stronger. Tempo helps turn your own recurring mistakes into useful study material so your training matches the positions you truly struggle with.",
    },
    {
      title: "Measure Long-Term Progress",
      text:
        "Improvement is easier when it is visible. Tempo helps track tournaments, openings, results, consistency, and lessons learned over time so progress feels concrete instead of random.",
    },
  ];

  const features = [
    {
      title: "Tournament Archive",
      text:
        "Keep each event organized with rounds, pairings, opponents, results, notes, and games stored in one clean timeline.",
    },
    {
      title: "Opening Insights",
      text:
        "See which openings lead to strong positions, difficult middlegames, or repeated problems in your own practice.",
    },
    {
      title: "Game Replay",
      text:
        "Step through moves smoothly, revisit critical moments, and understand where momentum changed.",
    },
    {
      title: "Study Workflow",
      text:
        "Move from game capture to review to training without jumping between multiple apps and folders.",
    },
    {
      title: "Voice Input Tools",
      text:
        "Useful recording tools can make move entry faster during casual games or post-game review sessions.",
    },
    {
      title: "Performance Dashboard",
      text:
        "Get a clearer picture of habits such as time trouble, recurring inaccuracies, and event-by-event form.",
    },
  ];

  return (
    <main
      style={{
        minHeight: "100vh",
        background:
          "radial-gradient(circle at top, #16213e 0%, #0b1220 30%, #050814 100%)",
        color: "#ffffff",
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
        overflowX: "hidden",
      }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto", padding: "28px 24px 100px" }}>
        {/* NAV */}
        <header
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            paddingBottom: 30,
          }}
        >
          <div
            style={{
              fontSize: 32,
              fontWeight: 900,
              letterSpacing: -1,
            }}
          >
            Tempo
          </div>

          <div style={{ display: "flex", gap: 12 }}>
            <button style={ghostBtn}>Sign In</button>
            <button style={primaryBtn}>Get Started</button>
          </div>
        </header>

        {/* HERO */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.1fr 0.9fr",
            gap: 34,
            alignItems: "center",
            minHeight: "84vh",
            paddingTop: 20,
          }}
        >
          <div
            style={{
              opacity: loaded ? 1 : 0,
              transform: loaded ? "translateY(0px)" : "translateY(30px)",
              transition: "all .9s ease",
            }}
          >
            <div style={pill}>A smarter operating system for chess improvement</div>

            <h1
              style={{
                fontSize: 86,
                lineHeight: 0.95,
                fontWeight: 900,
                letterSpacing: -3,
                margin: "18px 0 18px",
              }}
            >
              Turn every
              <br />
              game into growth.
            </h1>

            <p
              style={{
                color: "#9aa8c5",
                fontSize: 22,
                lineHeight: 1.8,
                maxWidth: 700,
                marginBottom: 30,
              }}
            >
              Tempo helps ambitious players capture games, study mistakes,
              organize tournament history, and build better habits over time.
              Instead of forgetting lessons after each round, you keep them and
              improve from them.
            </p>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <button style={primaryLarge}>Start Free</button>
              <button style={ghostLarge}>Explore Product</button>
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(3,1fr)",
                gap: 18,
                marginTop: 42,
                maxWidth: 720,
              }}
            >
              {[
                [
                  "Keep Every Game",
                  "No more lost scoresheets, forgotten ideas, or missing notes.",
                ],
                [
                  "Study Faster",
                  "Review key moments and learn efficiently after events.",
                ],
                [
                  "Improve Consistently",
                  "Build momentum through reflection and targeted training.",
                ],
              ].map(([title, text]) => (
                <div key={title}>
                  <div style={{ fontWeight: 800, marginBottom: 8 }}>{title}</div>
                  <div style={{ color: "#64748b", lineHeight: 1.6, fontSize: 14 }}>
                    {text}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* VISUAL PANEL */}
          <div
            style={{
              opacity: loaded ? 1 : 0,
              transform: loaded ? "translateY(0px)" : "translateY(40px)",
              transition: "all 1.1s ease",
            }}
          >
            <div style={glass}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 14,
                  marginBottom: 14,
                }}
              >
                <MiniCard
                  title="Recent Event"
                  value="City Championship"
                  text="4 rounds saved and organized"
                />
                <MiniCard
                  title="Main Theme"
                  value="Time Trouble"
                  text="Appearing late in games"
                />
              </div>

              <div style={innerCard}>
                <div style={smallMuted}>Recent Improvement Focus</div>

                <div
                  style={{
                    fontSize: 24,
                    fontWeight: 800,
                    marginTop: 12,
                    marginBottom: 16,
                  }}
                >
                  Converting Better Positions Calmly
                </div>

                <div
                  style={{
                    height: 10,
                    background: "#1f2937",
                    borderRadius: 999,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      width: "72%",
                      height: "100%",
                      background:
                        "linear-gradient(90deg,#38bdf8,#2563eb,#60a5fa)",
                    }}
                  />
                </div>

                <div
                  style={{
                    color: "#64748b",
                    marginTop: 12,
                    fontSize: 14,
                  }}
                >
                  Training progress this month
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  gap: 10,
                  flexWrap: "wrap",
                  marginTop: 14,
                }}
              >
                {[
                  "Games",
                  "Review",
                  "Training",
                  "Events",
                  "Openings",
                  "Notes",
                ].map((x) => (
                  <div key={x} style={chip}>
                    {x}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* PILLARS */}
        <section style={{ padding: "80px 0 30px" }}>
          <SectionTitle
            title="Built around how real players improve."
            text="Tempo is designed for the full cycle of competitive chess: play, review, learn, repeat."
          />

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2,1fr)",
              gap: 18,
              marginTop: 30,
            }}
          >
            {pillars.map((item) => (
              <div key={item.title} style={panelLarge}>
                <div
                  style={{
                    fontSize: 28,
                    fontWeight: 900,
                    marginBottom: 12,
                    letterSpacing: -0.5,
                  }}
                >
                  {item.title}
                </div>

                <div
                  style={{
                    color: "#94a3b8",
                    lineHeight: 1.9,
                    fontSize: 17,
                  }}
                >
                  {item.text}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* FEATURES */}
        <section style={{ padding: "90px 0 20px" }}>
          <SectionTitle
            title="Everything connected in one clean workspace."
            text="No scattered notes, folders, screenshots, or multiple tools."
          />

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3,1fr)",
              gap: 18,
              marginTop: 32,
            }}
          >
            {features.map((item) => (
              <div key={item.title} style={panel}>
                <div
                  style={{
                    fontSize: 22,
                    fontWeight: 800,
                    marginBottom: 10,
                  }}
                >
                  {item.title}
                </div>

                <div
                  style={{
                    color: "#94a3b8",
                    lineHeight: 1.8,
                    fontSize: 16,
                  }}
                >
                  {item.text}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section style={{ paddingTop: 100 }}>
          <div
            style={{
              background:
                "linear-gradient(135deg,rgba(37,99,235,.18),rgba(56,189,248,.08))",
              border: "1px solid rgba(255,255,255,.06)",
              borderRadius: 34,
              padding: "60px 36px",
              textAlign: "center",
            }}
          >
            <div
              style={{
                fontSize: 58,
                fontWeight: 900,
                letterSpacing: -2,
                marginBottom: 14,
              }}
            >
              Make each game worth more.
            </div>

            <p
              style={{
                color: "#9aa8c5",
                fontSize: 20,
                lineHeight: 1.8,
                maxWidth: 780,
                margin: "0 auto 26px",
              }}
            >
              Whether you are climbing rating ladders or preparing for major
              tournaments, Tempo helps turn experience into measurable progress.
            </p>

            <button style={primaryLarge}>Get Started</button>
          </div>
        </section>
      </div>
    </main>
  );
}

function SectionTitle({
  title,
  text,
}: {
  title: string;
  text: string;
}) {
  return (
    <>
      <div
        style={{
          fontSize: 58,
          fontWeight: 900,
          letterSpacing: -2,
          lineHeight: 1.05,
        }}
      >
        {title}
      </div>

      <div
        style={{
          color: "#94a3b8",
          fontSize: 19,
          lineHeight: 1.8,
          marginTop: 12,
          maxWidth: 760,
        }}
      >
        {text}
      </div>
    </>
  );
}

function MiniCard({
  title,
  value,
  text,
}: {
  title: string;
  value: string;
  text: string;
}) {
  return (
    <div style={innerCard}>
      <div style={smallMuted}>{title}</div>
      <div
        style={{
          marginTop: 10,
          fontWeight: 900,
          fontSize: 24,
        }}
      >
        {value}
      </div>
      <div style={{ color: "#94a3b8", marginTop: 8, lineHeight: 1.6 }}>
        {text}
      </div>
    </div>
  );
}

const primaryBtn = {
  background: "#2563eb",
  color: "white",
  border: "none",
  padding: "10px 16px",
  borderRadius: 999,
  fontWeight: 800,
  cursor: "pointer",
};

const ghostBtn = {
  background: "transparent",
  color: "#dbe3f3",
  border: "1px solid #1e293b",
  padding: "10px 16px",
  borderRadius: 999,
  cursor: "pointer",
};

const primaryLarge = {
  background: "linear-gradient(135deg,#2563eb,#38bdf8)",
  color: "white",
  border: "none",
  padding: "15px 26px",
  borderRadius: 16,
  fontWeight: 800,
  cursor: "pointer",
  fontSize: 16,
};

const ghostLarge = {
  background: "transparent",
  color: "#dbe3f3",
  border: "1px solid #1e293b",
  padding: "15px 26px",
  borderRadius: 16,
  fontWeight: 700,
  cursor: "pointer",
  fontSize: 16,
};

const pill = {
  display: "inline-block",
  background: "rgba(37,99,235,.12)",
  color: "#93c5fd",
  border: "1px solid rgba(37,99,235,.24)",
  padding: "8px 14px",
  borderRadius: 999,
  fontSize: 13,
  fontWeight: 700,
};

const glass = {
  background: "rgba(15,23,42,.8)",
  border: "1px solid rgba(255,255,255,.06)",
  borderRadius: 30,
  padding: 18,
  boxShadow: "0 30px 80px rgba(0,0,0,.45)",
};

const panel = {
  background: "#0f172a",
  border: "1px solid rgba(255,255,255,.05)",
  borderRadius: 28,
  padding: 24,
};

const panelLarge = {
  background: "#0f172a",
  border: "1px solid rgba(255,255,255,.05)",
  borderRadius: 30,
  padding: 28,
};

const innerCard = {
  background: "#111827",
  borderRadius: 24,
  padding: 18,
};

const chip = {
  background: "#111827",
  border: "1px solid #1f2937",
  padding: "10px 14px",
  borderRadius: 999,
  fontSize: 14,
  color: "#cbd5e1",
};

const smallMuted = {
  color: "#64748b",
  fontSize: 13,
};


