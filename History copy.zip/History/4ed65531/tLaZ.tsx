"use client";
import { useEffect, useState } from "react";

export default function Home() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    setShow(true);
  }, []);

  const sections = [
    {
      title: "Capture Games Effortlessly",
      desc: "Upload scoresheets, add moves manually, or record games naturally while playing.",
    },
    {
      title: "Understand Your Mistakes",
      desc: "Review missed tactics, inaccurate decisions, time pressure errors, and critical moments.",
    },
    {
      title: "Train What Matters",
      desc: "Turn your own mistakes into practical exercises and personalized improvement work.",
    },
    {
      title: "Track Real Progress",
      desc: "See patterns across tournaments, openings, opponents, and consistency over time.",
    },
  ];

  const detailCards = [
    ["Scoresheet Upload", "Convert written games into digital records."],
    ["Voice Move Input", "Record moves quickly during play sessions."],
    ["Game Review", "Replay games and inspect key positions."],
    ["Performance Trends", "Measure growth across events and months."],
    ["Opening Memory", "See what actually scores for you."],
    ["Training Queue", "Focus on mistakes that repeat most."],
  ];

  return (
    <main
      style={{
        background:
          "radial-gradient(circle at top,#13203e 0%,#0a0f1c 28%,#060b16 100%)",
        color: "white",
        minHeight: "100vh",
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
        overflowX: "hidden",
      }}
    >
      <div style={{ maxWidth: 1240, margin: "0 auto", padding: "26px 24px 100px" }}>
        {/* NAV */}
        <header
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            paddingBottom: 30,
          }}
        >
          <div style={{ fontSize: 30, fontWeight: 900, letterSpacing: -1 }}>
            Tempo
          </div>

          <div style={{ display: "flex", gap: 12 }}>
            <button style={ghostBtn}>Sign in</button>
            <button style={primaryBtn}>Get Started</button>
          </div>
        </header>

        {/* HERO */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.08fr 0.92fr",
            gap: 34,
            alignItems: "center",
            minHeight: "82vh",
          }}
        >
          <div
            style={{
              opacity: show ? 1 : 0,
              transform: show ? "translateY(0px)" : "translateY(30px)",
              transition: "all .8s ease",
            }}
          >
            <div style={pill}>Built for chess players who want to improve</div>

            <h1
              style={{
                fontSize: 82,
                lineHeight: 0.95,
                letterSpacing: -3,
                margin: "18px 0",
                fontWeight: 900,
              }}
            >
              Every game
              <br />
              becomes progress.
            </h1>

            <p
              style={{
                color: "#94a3b8",
                fontSize: 21,
                lineHeight: 1.75,
                maxWidth: 650,
                marginBottom: 28,
              }}
            >
              Tempo helps players capture games, review mistakes, organize tournament history,
              and train from real patterns in their own play.
            </p>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <button style={primaryLarge}>Start Free</button>
              <button style={ghostLarge}>See Product</button>
            </div>

            <div
              style={{
                display: "flex",
                gap: 36,
                marginTop: 36,
                flexWrap: "wrap",
              }}
            >
              {[
                ["Game Records", "Store and revisit your games"],
                ["Training Focus", "Improve using your own mistakes"],
                ["Tournament Memory", "Keep every event organized"],
              ].map(([t, s]) => (
                <div key={t}>
                  <div style={{ fontWeight: 800, fontSize: 18 }}>{t}</div>
                  <div style={{ color: "#64748b", fontSize: 14 }}>{s}</div>
                </div>
              ))}
            </div>
          </div>

          {/* APP PREVIEW */}
          <div
            style={{
              opacity: show ? 1 : 0,
              transform: show ? "translateY(0px)" : "translateY(40px)",
              transition: "all 1s ease",
            }}
          >
            <div
              style={{
                background: "rgba(15,23,42,.82)",
                border: "1px solid rgba(255,255,255,.06)",
                borderRadius: 30,
                padding: 18,
                boxShadow: "0 30px 80px rgba(0,0,0,.45)",
              }}
            >
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 14,
                  marginBottom: 14,
                }}
              >
                <MiniCard
                  title="Recent Game"
                  value="City Open R3"
                  sub="Stored and ready to review"
                />
                <MiniCard
                  title="Focus Theme"
                  value="Time Pressure"
                  sub="Appears often in losses"
                />
              </div>

              <div
                style={{
                  background: "#111827",
                  borderRadius: 24,
                  padding: 18,
                  marginBottom: 14,
                }}
              >
                <div style={mutedSmall}>Session Progress</div>

                <div
                  style={{
                    marginTop: 18,
                    display: "flex",
                    gap: 10,
                    alignItems: "flex-end",
                    height: 120,
                  }}
                >
                  {[28, 42, 60, 46, 72, 84, 68].map((h, i) => (
                    <div
                      key={i}
                      style={{
                        flex: 1,
                        height: `${h}%`,
                        borderRadius: 999,
                        background:
                          "linear-gradient(180deg,#38bdf8,#2563eb)",
                      }}
                    />
                  ))}
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  gap: 10,
                  flexWrap: "wrap",
                }}
              >
                {["Upload", "Review", "Train", "Track", "Replay"].map((tag) => (
                  <div key={tag} style={chip}>
                    {tag}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* VALUE STRIP */}
        <section
          style={{
            padding: "70px 0 40px",
            borderTop: "1px solid rgba(255,255,255,.05)",
            borderBottom: "1px solid rgba(255,255,255,.05)",
            marginTop: 20,
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: 18,
            }}
          >
            {sections.map((item) => (
              <div key={item.title}>
                <div style={{ fontWeight: 800, fontSize: 22, marginBottom: 10 }}>
                  {item.title}
                </div>
                <div style={{ color: "#94a3b8", lineHeight: 1.7 }}>
                  {item.desc}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* PRODUCT GRID */}
        <section style={{ padding: "90px 0 30px" }}>
          <div
            style={{
              fontSize: 56,
              fontWeight: 900,
              letterSpacing: -2,
              marginBottom: 14,
            }}
          >
            A complete system for serious players.
          </div>

          <p
            style={{
              color: "#94a3b8",
              fontSize: 19,
              maxWidth: 780,
              lineHeight: 1.75,
              marginBottom: 34,
            }}
          >
            Tempo is not just analysis. It is where your games, lessons,
            preparation, and improvement history live together.
          </p>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit,minmax(290px,1fr))",
              gap: 16,
            }}
          >
            {detailCards.map(([title, desc]) => (
              <div key={title} style={panel}>
                <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 10 }}>
                  {title}
                </div>
                <div style={{ color: "#94a3b8", lineHeight: 1.7 }}>{desc}</div>
              </div>
            ))}
          </div>
        </section>

        {/* WORKFLOW */}
        <section style={{ padding: "100px 0 40px" }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "0.95fr 1.05fr",
              gap: 22,
            }}
          >
            <div style={panel}>
              <div style={{ fontSize: 42, fontWeight: 900, marginBottom: 14 }}>
                How Tempo fits your routine
              </div>
              <p style={{ color: "#94a3b8", lineHeight: 1.8, fontSize: 18 }}>
                Play a game. Add it in minutes. Review key moments. See recurring
                patterns. Train those exact weaknesses. Repeat.
              </p>
            </div>

            <div style={panel}>
              {[
                "1. Capture the game",
                "2. Review critical moments",
                "3. Find repeating mistakes",
                "4. Build training tasks",
                "5. Return stronger next round",
              ].map((step) => (
                <div
                  key={step}
                  style={{
                    padding: "14px 0",
                    borderBottom: "1px solid rgba(255,255,255,.05)",
                    fontWeight: 700,
                  }}
                >
                  {step}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section style={{ paddingTop: 90 }}>
          <div
            style={{
              background:
                "linear-gradient(135deg,rgba(37,99,235,.16),rgba(56,189,248,.08))",
              border: "1px solid rgba(255,255,255,.06)",
              borderRadius: 32,
              padding: "52px 32px",
              textAlign: "center",
            }}
          >
            <div
              style={{
                fontSize: 54,
                fontWeight: 900,
                letterSpacing: -2,
                marginBottom: 14,
              }}
            >
              Start building better chess habits.
            </div>

            <p
              style={{
                color: "#94a3b8",
                fontSize: 19,
                maxWidth: 720,
                margin: "0 auto 24px",
                lineHeight: 1.7,
              }}
            >
              Keep your games organized, learn faster from mistakes, and make each
              tournament count.
            </p>

            <button style={primaryLarge}>Get Started</button>
          </div>
        </section>
      </div>
    </main>
  );
}

function MiniCard({
  title,
  value,
  sub,
}: {
  title: string;
  value: string;
  sub: string;
}) {
  return (
    <div
      style={{
        background: "#111827",
        borderRadius: 22,
        padding: 16,
      }}
    >
      <div style={{ color: "#64748b", fontSize: 13 }}>{title}</div>
      <div style={{ marginTop: 10, fontWeight: 900, fontSize: 26 }}>{value}</div>
      <div style={{ color: "#94a3b8", fontSize: 14 }}>{sub}</div>
    </div>
  );
}

const primaryBtn = {
  background: "#2563eb",
  color: "white",
  border: "none",
  padding: "10px 16px",
  borderRadius: 999,
  fontWeight: 800,
  cursor: "pointer",
};

const ghostBtn = {
  background: "transparent",
  color: "#cbd5e1",
  border: "1px solid #1e293b",
  padding: "10px 16px",
  borderRadius: 999,
  cursor: "pointer",
};

const primaryLarge = {
  background: "linear-gradient(135deg,#2563eb,#38bdf8)",
  color: "white",
  border: "none",
  padding: "15px 24px",
  borderRadius: 16,
  fontWeight: 800,
  cursor: "pointer",
};

const ghostLarge = {
  background: "transparent",
  color: "#e2e8f0",
  border: "1px solid #1e293b",
  padding: "15px 24px",
  borderRadius: 16,
  fontWeight: 700,
  cursor: "pointer",
};

const pill = {
  display: "inline-block",
  background: "rgba(37,99,235,.12)",
  color: "#93c5fd",
  border: "1px solid rgba(37,99,235,.22)",
  padding: "8px 14px",
  borderRadius: 999,
  fontSize: 13,
  fontWeight: 700,
};

const chip = {
  background: "#111827",
  border: "1px solid #1e293b",
  padding: "10px 14px",
  borderRadius: 999,
  fontSize: 14,
  color: "#cbd5e1",
};

const panel = {
  background: "#0f172a",
  border: "1px solid rgba(255,255,255,.05)",
  borderRadius: 28,
  padding: 24,
};

const mutedSmall = {
  color: "#64748b",
  fontSize: 13,
};