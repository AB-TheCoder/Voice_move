"use client";
import { useEffect, useState } from "react";

export default function Home() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    setShow(true);
  }, []);

  const features = [
    "Scan Scoresheets",
    "Live Engine Analysis",
    "Tournament Dashboard",
    "Voice Chess Clock",
    "Mistake Detection",
    "Training Puzzles",
  ];

  return (
    <main
      style={{
        minHeight: "100vh",
        background:
          "linear-gradient(180deg,#060b16 0%, #0b1220 45%, #0f172a 100%)",
        color: "white",
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
        overflowX: "hidden",
      }}
    >
      <div style={{ maxWidth: 1220, margin: "0 auto", padding: "24px" }}>
        {/* NAV */}
        <nav
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "12px 0 28px",
          }}
        >
          <div
            style={{
              fontSize: 30,
              fontWeight: 900,
              letterSpacing: -1,
            }}
          >
            Tempo
          </div>

          <div style={{ display: "flex", gap: 12 }}>
            <button
              style={{
                background: "transparent",
                color: "#cbd5e1",
                border: "1px solid #1e293b",
                padding: "10px 16px",
                borderRadius: 999,
                cursor: "pointer",
              }}
            >
              Login
            </button>

            <button
              style={{
                background: "#2563eb",
                border: "none",
                color: "white",
                padding: "10px 18px",
                borderRadius: 999,
                fontWeight: 800,
                cursor: "pointer",
                boxShadow: "0 10px 30px rgba(37,99,235,.35)",
              }}
            >
              Start Free
            </button>
          </div>
        </nav>

        {/* HERO */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.05fr 0.95fr",
            gap: 30,
            alignItems: "center",
            minHeight: "82vh",
          }}
        >
          {/* LEFT */}
          <div
            style={{
              transform: show ? "translateY(0px)" : "translateY(30px)",
              opacity: show ? 1 : 0,
              transition: "all 0.8s ease",
            }}
          >
            <div
              style={{
                display: "inline-block",
                background: "rgba(37,99,235,.12)",
                color: "#93c5fd",
                border: "1px solid rgba(37,99,235,.25)",
                padding: "8px 14px",
                borderRadius: 999,
                fontSize: 13,
                fontWeight: 700,
                marginBottom: 20,
              }}
            >
              Chess Performance Platform
            </div>

            <h1
              style={{
                fontSize: 78,
                lineHeight: 0.95,
                fontWeight: 900,
                letterSpacing: -3,
                margin: "0 0 18px",
              }}
            >
              Improve
              <br />
              with data.
            </h1>

            <p
              style={{
                fontSize: 21,
                color: "#94a3b8",
                lineHeight: 1.7,
                maxWidth: 620,
                marginBottom: 28,
              }}
            >
              Tempo captures your games, analyzes mistakes, tracks tournament
              performance, and turns every result into progress.
            </p>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <button
                style={{
                  background:
                    "linear-gradient(135deg,#2563eb,#3b82f6,#06b6d4)",
                  border: "none",
                  color: "white",
                  padding: "15px 24px",
                  borderRadius: 16,
                  fontWeight: 800,
                  fontSize: 16,
                  cursor: "pointer",
                  boxShadow: "0 12px 30px rgba(37,99,235,.35)",
                }}
              >
                Analyze My Games
              </button>

              <button
                style={{
                  background: "transparent",
                  border: "1px solid #1e293b",
                  color: "#e2e8f0",
                  padding: "15px 24px",
                  borderRadius: 16,
                  fontWeight: 700,
                  cursor: "pointer",
                }}
              >
                See Demo
              </button>
            </div>

            <div
              style={{
                display: "flex",
                gap: 34,
                marginTop: 34,
                flexWrap: "wrap",
              }}
            >
              {[
                ["18k+", "Games analyzed"],
                ["91%", "Users improve review habits"],
                ["2 min", "Avg upload to report"],
              ].map(([n, t]) => (
                <div key={t}>
                  <div style={{ fontSize: 28, fontWeight: 900 }}>{n}</div>
                  <div style={{ color: "#64748b", fontSize: 14 }}>{t}</div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT PANEL */}
          <div
            style={{
              transform: show ? "translateY(0px)" : "translateY(40px)",
              opacity: show ? 1 : 0,
              transition: "all 1s ease",
            }}
          >
            <div
              style={{
                background: "rgba(15,23,42,.8)",
                border: "1px solid rgba(255,255,255,.06)",
                borderRadius: 28,
                padding: 18,
                boxShadow: "0 30px 80px rgba(0,0,0,.45)",
              }}
            >
              {/* top row */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 14,
                  marginBottom: 14,
                }}
              >
                <Card
                  title="Current Event"
                  value="National Open"
                  sub="Round 5 today"
                />
                <Card title="Live Eval" value="+1.8" sub="Winning chances high" />
              </div>

              {/* chart */}
              <div
                style={{
                  background: "#111827",
                  borderRadius: 22,
                  padding: 18,
                  marginBottom: 14,
                }}
              >
                <div style={{ color: "#64748b", fontSize: 13 }}>
                  Accuracy Trend
                </div>

                <div
                  style={{
                    marginTop: 18,
                    display: "flex",
                    alignItems: "flex-end",
                    gap: 10,
                    height: 120,
                  }}
                >
                  {[35, 55, 48, 72, 68, 90, 82].map((h, i) => (
                    <div
                      key={i}
                      style={{
                        flex: 1,
                        height: `${h}%`,
                        borderRadius: 999,
                        background:
                          "linear-gradient(180deg,#38bdf8,#2563eb)",
                        animation: `grow 1s ease ${i * 0.1}s both`,
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* feature pills */}
              <div
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 10,
                }}
              >
                {features.map((f, i) => (
                  <div
                    key={f}
                    style={{
                      background: "#111827",
                      border: "1px solid #1f2937",
                      padding: "10px 14px",
                      borderRadius: 999,
                      fontSize: 14,
                      color: "#cbd5e1",
                      animation: `fadeIn .6s ease ${i * 0.08}s both`,
                    }}
                  >
                    {f}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* SECOND SECTION */}
        <section
          style={{
            padding: "20px 0 90px",
          }}
        >
          <div
            style={{
              fontSize: 52,
              fontWeight: 900,
              letterSpacing: -2,
              marginBottom: 14,
            }}
          >
            Built to win tournaments.
          </div>

          <p
            style={{
              color: "#94a3b8",
              fontSize: 19,
              maxWidth: 760,
              lineHeight: 1.7,
              marginBottom: 26,
            }}
          >
            Tempo helps competitive players prepare better, review faster, and
            learn from every game without wasting time.
          </p>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))",
              gap: 16,
            }}
          >
            {[
              ["Instant Uploads", "Photo to PGN in minutes."],
              ["Engine Reports", "Blunders, tactics, plans."],
              ["Opening Memory", "Track results by opening."],
              ["Voice Clock", "Record moves while playing."],
            ].map(([t, d]) => (
              <div
                key={t}
                style={{
                  background: "#0f172a",
                  border: "1px solid #1e293b",
                  borderRadius: 24,
                  padding: 22,
                }}
              >
                <div style={{ fontSize: 20, fontWeight: 800 }}>{t}</div>
                <div
                  style={{
                    marginTop: 10,
                    color: "#94a3b8",
                    lineHeight: 1.7,
                  }}
                >
                  {d}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <style jsx global>{`
        @keyframes grow {
          from {
            height: 0%;
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes fadeIn {
          from {
            transform: translateY(8px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        button {
          transition: all 0.2s ease;
        }

        button:hover {
          transform: translateY(-2px);
          opacity: 0.95;
        }
      `}</style>
    </main>
  );
}

function Card({
  title,
  value,
  sub,
}: {
  title: string;
  value: string;
  sub: string;
}) {
  return (
    <div
      style={{
        background: "#111827",
        borderRadius: 22,
        padding: 16,
      }}
    >
      <div style={{ color: "#64748b", fontSize: 13 }}>{title}</div>
      <div
        style={{
          marginTop: 10,
          fontSize: 30,
          fontWeight: 900,
        }}
      >
        {value}
      </div>
      <div style={{ color: "#94a3b8", fontSize: 14 }}>{sub}</div>
    </div>
  );
}