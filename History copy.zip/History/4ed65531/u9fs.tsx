export default function Home() {
  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#0f172a",
        color: "white",
        fontFamily: "Arial, sans-serif",
        padding: "40px",
      }}
    >
      <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
        <h1 style={{ fontSize: "64px", fontWeight: 700, marginBottom: "10px" }}>
          Tempo
        </h1>

        <p
          style={{
            fontSize: "22px",
            color: "#94a3b8",
            marginBottom: "40px",
          }}
        >
          Play. Analyze. Improve.
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))",
            gap: "20px",
            marginBottom: "40px",
          }}
        >
          {[
            "Upload Scoresheet",
            "Instant PGN",
            "Engine Analysis",
            "Tournament Mode",
            "Voice Chess Clock",
            "AI Insights",
          ].map((item) => (
            <div
              key={item}
              style={{
                background: "#1e293b",
                padding: "24px",
                borderRadius: "18px",
              }}
            >
              <h3>{item}</h3>
              <p style={{ color: "#94a3b8", fontSize: "14px" }}>
                Core Tempo feature
              </p>
            </div>
          ))}
        </div>

        <div
          style={{
            background: "#1e293b",
            padding: "30px",
            borderRadius: "20px",
            marginBottom: "30px",
          }}
        >
          <h2>Upload Scoresheet</h2>

          <input type="file" style={{ marginTop: "15px" }} />

          <button
            style={{
              display: "block",
              marginTop: "20px",
              padding: "12px 20px",
              background: "#2563eb",
              color: "white",
              border: "none",
              borderRadius: "12px",
              cursor: "pointer",
            }}
          >
            Process Image
          </button>
        </div>

        <div
          style={{
            background: "#1e293b",
            padding: "30px",
            borderRadius: "20px",
          }}
        >
          <h2>Sample PGN Output</h2>
          <p style={{ color: "#94a3b8" }}>
            1. e4 e5 2. Nf3 Nc6 3. Bb5 a6
          </p>
        </div>
      </div>
    </main>
  );
}