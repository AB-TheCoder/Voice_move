export default function Home() {
  const features = [
    ["Game Capture", "Upload scoresheets or enter moves quickly after every round."],
    ["Deep Analysis", "Review mistakes, missed wins, turning points, and best plans."],
    ["Tournament Memory", "Store every event, opponent, result, and lesson learned."],
    ["Voice Clock", "Record moves naturally while playing with smart tap controls."],
    ["Training Engine", "Convert your real mistakes into puzzles and drills."],
    ["Progress Tracking", "See rating trends, openings, time trouble, and consistency."],
  ];

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#0a0f1c",
        color: "#f8fafc",
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
      }}
    >
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "28px 24px 80px" }}>
        {/* NAVBAR */}
        <header
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "8px 0 28px",
          }}
        >
          <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: -1 }}>
            Tempo
          </div>

          <div style={{ display: "flex", gap: 12 }}>
            <button
              style={{
                background: "transparent",
                color: "#cbd5e1",
                border: "1px solid #1e293b",
                padding: "10px 16px",
                borderRadius: 999,
                cursor: "pointer",
              }}
            >
              Sign in
            </button>

            <button
              style={{
                background: "#2563eb",
                color: "white",
                border: "none",
                padding: "10px 16px",
                borderRadius: 999,
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Get access
            </button>
          </div>
        </header>

        {/* HERO */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.1fr 0.9fr",
            gap: 28,
            alignItems: "center",
            padding: "40px 0 70px",
          }}
        >
          <div>
            <div
              style={{
                display: "inline-block",
                background: "#0f172a",
                border: "1px solid #1e293b",
                color: "#93c5fd",
                padding: "8px 14px",
                borderRadius: 999,
                fontSize: 13,
                fontWeight: 700,
                marginBottom: 18,
              }}
            >
              Built for serious chess players
            </div>

            <h1
              style={{
                fontSize: 72,
                lineHeight: 0.96,
                margin: "0 0 18px",
                letterSpacing: -3,
                fontWeight: 850,
              }}
            >
              Your chess
              <br />
              progress system.
            </h1>

            <p
              style={{
                fontSize: 20,
                color: "#94a3b8",
                lineHeight: 1.65,
                maxWidth: 620,
                marginBottom: 28,
              }}
            >
              Tempo turns every tournament game into measurable improvement.
              Capture games, analyze mistakes, train weaknesses, and track growth.
            </p>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <button
                style={{
                  background: "#2563eb",
                  color: "white",
                  border: "none",
                  padding: "14px 22px",
                  borderRadius: 14,
                  fontWeight: 800,
                  cursor: "pointer",
                }}
              >
                Start free
              </button>

              <button
                style={{
                  background: "transparent",
                  color: "#e2e8f0",
                  border: "1px solid #1e293b",
                  padding: "14px 22px",
                  borderRadius: 14,
                  fontWeight: 700,
                  cursor: "pointer",
                }}
              >
                Watch demo
              </button>
            </div>

            <div
              style={{
                display: "flex",
                gap: 28,
                marginTop: 34,
                flexWrap: "wrap",
              }}
            >
              {[
                ["12k+", "Games analyzed"],
                ["89%", "Users improve consistency"],
                ["24/7", "Instant engine review"],
              ].map(([num, text]) => (
                <div key={text}>
                  <div style={{ fontSize: 28, fontWeight: 800 }}>{num}</div>
                  <div style={{ color: "#64748b", fontSize: 14 }}>{text}</div>
                </div>
              ))}
            </div>
          </div>

          {/* PRODUCT PREVIEW */}
          <div
            style={{
              background: "#0f172a",
              border: "1px solid #1e293b",
              borderRadius: 26,
              padding: 18,
              boxShadow: "0 20px 60px rgba(0,0,0,0.35)",
            }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 14,
                marginBottom: 14,
              }}
            >
              <div
                style={{
                  background: "#111827",
                  borderRadius: 18,
                  padding: 16,
                }}
              >
                <div style={{ color: "#64748b", fontSize: 13 }}>Latest Game</div>
                <div style={{ marginTop: 10, fontWeight: 700 }}>
                  Open Championship R5
                </div>
                <div style={{ marginTop: 12, color: "#94a3b8", fontSize: 14 }}>
                  1. e4 c5 2. Nf3 d6 3. d4
                </div>
              </div>

              <div
                style={{
                  background: "#111827",
                  borderRadius: 18,
                  padding: 16,
                }}
              >
                <div style={{ color: "#64748b", fontSize: 13 }}>Evaluation</div>
                <div
                  style={{
                    marginTop: 10,
                    fontSize: 30,
                    fontWeight: 800,
                    color: "#22c55e",
                  }}
                >
                  +1.3
                </div>
                <div style={{ color: "#94a3b8", fontSize: 14 }}>
                  Best move found
                </div>
              </div>
            </div>

            <div
              style={{
                background: "#111827",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <div style={{ color: "#64748b", fontSize: 13 }}>
                Recurring Weakness
              </div>
              <div style={{ marginTop: 10, fontWeight: 700 }}>
                Rushing in winning positions
              </div>

              <div
                style={{
                  marginTop: 16,
                  height: 8,
                  borderRadius: 999,
                  background: "#1e293b",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: "74%",
                    height: "100%",
                    background: "#2563eb",
                  }}
                />
              </div>
            </div>
          </div>
        </section>

        {/* FEATURES */}
        <section style={{ padding: "20px 0 70px" }}>
          <div
            style={{
              fontSize: 42,
              fontWeight: 850,
              letterSpacing: -1.5,
              marginBottom: 10,
            }}
          >
            Built for real improvement
          </div>

          <p
            style={{
              color: "#94a3b8",
              fontSize: 18,
              marginBottom: 28,
              maxWidth: 760,
              lineHeight: 1.6,
            }}
          >
            Tempo combines tournament discipline, engine precision, and modern
            product design into one system.
          </p>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))",
              gap: 16,
            }}
          >
            {features.map(([title, desc]) => (
              <div
                key={title}
                style={{
                  background: "#0f172a",
                  border: "1px solid #1e293b",
                  borderRadius: 22,
                  padding: 22,
                }}
              >
                <div
                  style={{
                    fontSize: 19,
                    fontWeight: 800,
                    marginBottom: 10,
                  }}
                >
                  {title}
                </div>

                <div
                  style={{
                    color: "#94a3b8",
                    lineHeight: 1.7,
                    fontSize: 15,
                  }}
                >
                  {desc}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section
          style={{
            background: "#0f172a",
            border: "1px solid #1e293b",
            borderRadius: 28,
            padding: "42px 28px",
            textAlign: "center",
          }}
        >
          <div
            style={{
              fontSize: 44,
              fontWeight: 850,
              letterSpacing: -1.5,
              marginBottom: 12,
            }}
          >
            Every game should count.
          </div>

          <p
            style={{
              color: "#94a3b8",
              fontSize: 18,
              marginBottom: 24,
            }}
          >
            Stop forgetting lessons from your games. Build progress with Tempo.
          </p>

          <button
            style={{
              background: "#2563eb",
              color: "white",
              border: "none",
              padding: "14px 24px",
              borderRadius: 14,
              fontWeight: 800,
              cursor: "pointer",
              fontSize: 16,
            }}
          >
            Join early access
          </button>
        </section>
      </div>
    </main>
  );
}