export default function Home() {
  const features = [
    {
      title: "Scoresheet Scanner",
      desc: "Upload handwritten tournament scoresheets and convert them into clean PGN instantly.",
    },
    {
      title: "Engine Analysis",
      desc: "Stockfish-powered blunder detection, evaluations, best lines, and turning points.",
    },
    {
      title: "Tournament Mode",
      desc: "Track events, store games, and discover recurring mistakes across tournaments.",
    },
    {
      title: "Voice Chess Clock",
      desc: "Tap the clock, speak the move, and automatically record the full game.",
    },
    {
      title: "AI Coach",
      desc: "Tempo learns your weaknesses and gives targeted improvement suggestions.",
    },
    {
      title: "Training Mode",
      desc: "Turn your own mistakes into puzzles, drills, and practical exercises.",
    },
  ];

  return (
    <main
      style={{
        minHeight: "100vh",
        background:
          "radial-gradient(circle at top, #172554 0%, #0f172a 35%, #020617 100%)",
        color: "white",
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
      }}
    >
      <div
        style={{
          maxWidth: "1180px",
          margin: "0 auto",
          padding: "40px 24px 80px",
        }}
      >
        {/* NAV */}
        <nav
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "70px",
          }}
        >
          <div
            style={{
              fontSize: "28px",
              fontWeight: 800,
              letterSpacing: "-1px",
            }}
          >
            Tempo
          </div>

          <div
            style={{
              display: "flex",
              gap: "14px",
            }}
          >
            <button
              style={{
                background: "transparent",
                color: "#cbd5e1",
                border: "1px solid #334155",
                padding: "10px 18px",
                borderRadius: "12px",
                cursor: "pointer",
              }}
            >
              Log In
            </button>

            <button
              style={{
                background: "linear-gradient(135deg,#2563eb,#06b6d4)",
                color: "white",
                border: "none",
                padding: "10px 18px",
                borderRadius: "12px",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Get Started
            </button>
          </div>
        </nav>

        {/* HERO */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.1fr 0.9fr",
            gap: "32px",
            alignItems: "center",
            marginBottom: "80px",
          }}
        >
          <div>
            <p
              style={{
                color: "#38bdf8",
                fontWeight: 700,
                marginBottom: "14px",
                letterSpacing: "0.4px",
              }}
            >
              CHESS IMPROVEMENT PLATFORM
            </p>

            <h1
              style={{
                fontSize: "72px",
                lineHeight: 1,
                margin: "0 0 18px",
                fontWeight: 850,
                letterSpacing: "-2px",
              }}
            >
              Play.
              <br />
              Analyze.
              <br />
              Improve.
            </h1>

            <p
              style={{
                color: "#94a3b8",
                fontSize: "20px",
                lineHeight: 1.6,
                maxWidth: "620px",
                marginBottom: "28px",
              }}
            >
              Tempo automatically turns every chess game you play into real
              progress. Upload scoresheets, analyze mistakes, track tournaments,
              and train smarter.
            </p>

            <div style={{ display: "flex", gap: "14px", flexWrap: "wrap" }}>
              <button
                style={{
                  background: "linear-gradient(135deg,#2563eb,#06b6d4)",
                  color: "white",
                  border: "none",
                  padding: "14px 24px",
                  borderRadius: "14px",
                  fontWeight: 800,
                  fontSize: "16px",
                  cursor: "pointer",
                }}
              >
                Start Free
              </button>

              <button
                style={{
                  background: "rgba(255,255,255,0.03)",
                  color: "white",
                  border: "1px solid #334155",
                  padding: "14px 24px",
                  borderRadius: "14px",
                  fontWeight: 700,
                  fontSize: "16px",
                  cursor: "pointer",
                }}
              >
                View Demo
              </button>
            </div>
          </div>

          {/* MOCK APP PANEL */}
          <div
            style={{
              background: "rgba(15,23,42,0.85)",
              border: "1px solid rgba(148,163,184,0.18)",
              borderRadius: "24px",
              padding: "22px",
              boxShadow: "0 30px 80px rgba(0,0,0,0.45)",
            }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "16px",
                marginBottom: "16px",
              }}
            >
              <div
                style={{
                  background: "#111827",
                  borderRadius: "18px",
                  padding: "18px",
                }}
              >
                <p style={{ color: "#64748b", fontSize: "13px" }}>
                  Uploaded Game
                </p>
                <p style={{ fontWeight: 700, marginTop: "10px" }}>
                  State Championship R4
                </p>
                <p style={{ color: "#94a3b8", marginTop: "10px" }}>
                  1. e4 e5 2. Nf3 Nc6
                </p>
              </div>

              <div
                style={{
                  background: "#111827",
                  borderRadius: "18px",
                  padding: "18px",
                }}
              >
                <p style={{ color: "#64748b", fontSize: "13px" }}>
                  Engine Verdict
                </p>
                <p
                  style={{
                    fontWeight: 800,
                    marginTop: "10px",
                    color: "#22c55e",
                  }}
                >
                  +1.7 White
                </p>
                <p style={{ color: "#94a3b8", marginTop: "10px" }}>
                  Missed tactic on move 23
                </p>
              </div>
            </div>

            <div
              style={{
                background: "#111827",
                borderRadius: "18px",
                padding: "18px",
              }}
            >
              <p style={{ color: "#64748b", fontSize: "13px" }}>
                Tournament Insights
              </p>
              <p style={{ marginTop: "10px", fontWeight: 700 }}>
                Most blunders happen in time pressure.
              </p>
              <div
                style={{
                  height: "10px",
                  background: "#1e293b",
                  borderRadius: "999px",
                  marginTop: "16px",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: "72%",
                    height: "100%",
                    background:
                      "linear-gradient(90deg,#06b6d4,#3b82f6,#22c55e)",
                  }}
                />
              </div>
            </div>
          </div>
        </section>

        {/* FEATURES */}
        <section style={{ marginBottom: "80px" }}>
          <h2
            style={{
              fontSize: "38px",
              marginBottom: "14px",
              fontWeight: 800,
            }}
          >
            Everything needed to improve faster
          </h2>

          <p
            style={{
              color: "#94a3b8",
              fontSize: "18px",
              marginBottom: "28px",
            }}
          >
            Built for serious players, ambitious students, and competitive
            tournament grinders.
          </p>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))",
              gap: "18px",
            }}
          >
            {features.map((item) => (
              <div
                key={item.title}
                style={{
                  background: "rgba(15,23,42,0.72)",
                  border: "1px solid rgba(148,163,184,0.12)",
                  borderRadius: "22px",
                  padding: "22px",
                }}
              >
                <h3
                  style={{
                    margin: "0 0 10px",
                    fontSize: "20px",
                    fontWeight: 800,
                  }}
                >
                  {item.title}
                </h3>
                <p
                  style={{
                    color: "#94a3b8",
                    lineHeight: 1.7,
                    margin: 0,
                  }}
                >
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section
          style={{
            background:
              "linear-gradient(135deg, rgba(37,99,235,0.22), rgba(6,182,212,0.18))",
            border: "1px solid rgba(148,163,184,0.14)",
            borderRadius: "28px",
            padding: "40px",
            textAlign: "center",
          }}
        >
          <h2
            style={{
              fontSize: "42px",
              marginBottom: "12px",
              fontWeight: 850,
            }}
          >
            Every game should become progress.
          </h2>

          <p
            style={{
              color: "#cbd5e1",
              fontSize: "18px",
              marginBottom: "24px",
            }}
          >
            Stop losing data. Start improving with Tempo.
          </p>

          <button
            style={{
              background: "linear-gradient(135deg,#2563eb,#06b6d4)",
              color: "white",
              border: "none",
              padding: "14px 26px",
              borderRadius: "14px",
              fontWeight: 800,
              cursor: "pointer",
              fontSize: "16px",
            }}
          >
            Join Early Access
          </button>
        </section>
      </div>
    </main>
  );
}