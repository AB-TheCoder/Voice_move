import tkinter as tk
import random
import sys, os

def resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

from PIL import Image, ImageTk


def cycle_fact():
    new_fact = random.choice(facts)
    fact_label.config(text=new_fact)
    root.after(20000, cycle_fact)

#main application window
root = tk.Tk()
neuron_img = Image.open(resource_path("neuron.png")).resize((100, 100))
neuron_photo = ImageTk.PhotoImage(neuron_img)
root.title("Synapse Clicker")
root.geometry("800x600")
root.configure(bg="#1E1E1E")


#fact bar
fact_bar = tk.Frame(root, bg='#2D2D2D', height=40)
fact_bar.grid(row=0, column=0, columnspan=2, sticky='ew')

#main panel
main_panel = tk.Frame(root, bg='#1E1E1E')
main_panel.grid(row=1, column=0, sticky='nsew')

#shop panel
shop_panel = tk.Frame(root, bg='#2D2D2D')
shop_panel.grid(row=1, column=1, sticky='nsew')

#main content window expands when window resizes
root.grid_rowconfigure(1, weight=1)
root.grid_columnconfigure(0, weight=3)  # for main panel
root.grid_columnconfigure(1, weight=1)  # for shop panel getting smaller


#VARIABLES
total_neurotransmitters = 0
click_multiplier = 1
nts_per_second = 0

#facts content here
facts = [
    "Did you know that the human brain contains approximately 86 billion neurons? ",
    "Did you know that information in the brain is transmitted at speeds of up to 250 miles per hour? ",
    "Did you know that a single neuron can connect to 10,000 other neurons, forming complex networks? "
]
fact_label = tk.Label(fact_bar, text=facts[0], bg='#2D2D2D', fg='#E0E0E0', font=('helvetica', 14, "bold"))
fact_label.pack(pady=8)

cycle_fact()  # NOW start the calling of the fact: (previous mistake: called the fact inside the function itself lol, causing recursion error)

#main panel content
nt_display = tk.Label(main_panel, text='0', bg='#1E1E1E', fg="#D5E520", font=('helvetica', 40, "bold"))
nt_display.pack(pady=(30, 0))

nt_label = tk.Label(main_panel, text='Neurotransmitters', bg='#1E1E1E', fg='#E0E0E0', font=('helvetica', 14, 'bold'))
nt_label.pack()

rate_label = tk.Label(main_panel, text="(+0.0 NTs/Second)", bg='#1E1E1E', fg="#14C5F1", font=('helvetica', 14, 'bold'))
rate_label.pack(pady=(30, 0))

def refresh_ui():
    nt_display.config(text=f"{int(total_neurotransmitters)}")
    rate_label.config(text=f"(+{nts_per_second:.1f} NTs/Second)")
    for key, widgets in upgrade_widgets.items():
        widgets["level_label"].config(text=f"Level: {upgrades[key]['level']}")
        widgets["cost_label"].config(text=f"Cost: {get_cost(key)} NTs  ")

def fire_neuron():
    global total_neurotransmitters
    total_neurotransmitters += click_multiplier
    refresh_ui()


neuron_button = tk.Label(
    main_panel, image=neuron_photo, bg="#1E1E1E", cursor="hand2" 
)
neuron_button.image = neuron_photo
neuron_button.pack(pady=17)
neuron_button.bind("<Button-1>", lambda e: fire_neuron())

#shop content here
shop_title = tk.Label(shop_panel, text="SHOP", bg="#2D2D2D", fg="#E0E0E0", font=("Helvetica", 20, "bold"))
shop_title.pack(pady=15)

#shop data
upgrades = {
    "dendrites": {"name": "Dendrite Branching", "level": 0, "base_cost": 15, "effect": "click"},
    "glial": {"name": "Glial Cell Support", "level": 0, "base_cost": 100, "effect": "passive"},
    "myelin": {"name": "Myelin Sheath", "level": 0, "base_cost": 500, "effect": "multiplier"},
}

#pricing in shop
def get_cost(key):
    data = upgrades[key]
    return int(data["base_cost"] * (1.15 ** data["level"]))

#buy logic
upgrade_widgets = {}

def buy_upgrade(key):
    global total_neurotransmitters, click_multiplier, nts_per_second
    cost = get_cost(key)
    if total_neurotransmitters >= cost:
        total_neurotransmitters -= cost
        upgrades[key]["level"] += 1

        if upgrades[key]["effect"] == "click":
            click_multiplier += 1
        elif upgrades[key]["effect"] == "passive":
            nts_per_second += 1
        elif upgrades[key]["effect"] == "multiplier":
            nts_per_second *= 1.5

        refresh_ui()

for key in upgrades:
    row = tk.Frame(shop_panel, bg="#2D2D2D")
    row.pack(pady=10, padx=10, fill='x')

    name_label = tk.Label(row, text=upgrades[key]["name"], bg="#2D2D2D", fg="#E0E0E0", font=("Helvetica", 16, "bold"))
    name_label.pack(anchor="w")

    level_label = tk.Label(row, text=f"Level: {upgrades[key]['level']}", bg="#2D2D2D", fg="#E0E0E0", font=("Helvetica", 16))
    level_label.pack(anchor="w")

    cost_label = tk.Label(row, text=f"Cost: {get_cost(key)} NTs", bg="#2D2D2D", fg="#E0E0E0", font=("Helvetica", 16))
    cost_label.pack(anchor="w")

    buy_button = tk.Button(row, text="Buy", command=lambda k=key: buy_upgrade(k), bg="#393E46", fg="#E0E0E0")
    buy_button.pack(anchor="w", pady=(4, 0))

    upgrade_widgets[key] = {"level_label": level_label, "cost_label": cost_label}


root.mainloop()  # lesson learnt: mainloop should always be last