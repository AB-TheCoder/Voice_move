import 'package:flutter/material.dart';

void main() {
  runApp(const VccnApp());
}

class VccnApp extends StatelessWidget {
  const VccnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VCCN',
      home: const ClockScreen(),
    );
  }
}

class ClockScreen extends StatefulWidget {
  const ClockScreen({super.key});

  @override
  State<ClockScreen> createState() => _ClockScreenState();
}

class _ClockScreenState extends State<ClockScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          Expanded(
            child: Transform.rotate(
              angle: 3.14159,
              child: Container(
                color: Colors.grey[600],
                width: double.infinity,
                child: const Center(
                  child: Text(
                    '15:00',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 72,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Container(
            color: Colors.grey[900],
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: const [
                Icon(Icons.refresh, color: Colors.white),
                Icon(Icons.play_arrow, color: Colors.white),
                Icon(Icons.tune, color: Colors.white),
                Icon(Icons.volume_up, color: Colors.white),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: Colors.grey[600],
              width: double.infinity,
              child: const Center(
                child: Text(
                  '15:00',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 72,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}