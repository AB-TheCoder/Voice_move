import 'package:flutter/material.dart';

void main() {
    runApp(const VccnApp());
}

class VccnApp extends StatelessWeight {
    const VccnApp ({super.key});

    @override
    Widget build(BuildContext context) {
        return MaterialApp(
            title: 'VCCN',
            home: const ClockScreen(),
        );
    }
}

class ClockScreen extends StatefulWidget {
    const ClockScreen({super.key});

    @override
    State<ClockScreen> createState => _ClockScreenState();
}

class _ClockScreenState extends State<ClockScreen> {
    @override 
    Widget build(BuildContext context) {
        return Scaffold(
            body: Center(
                child: Text("VCCN"),
            ),
        );
    }
}

class _