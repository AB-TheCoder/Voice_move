import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';

void main() {
  runApp(const VccnApp());
}

class VccnApp extends StatelessWidget {
  const VccnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedmodebanner: false,
        title: 'VCCN',
        home: const ClockScreen(),
        );
    }
}

class ClockScreen extends StatefulWidget {
  const ClockScreen({super.key});

  @override
  State<ClockScreen> createState() => _ClockScreenState();
}

class _ClockScreenState extends State<ClockScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
        children: [

            // Black's side of the screen(inverted)
          Expanded(
            child: Transform.rotate(
              angle: pi, //i wrote pi instead of 3.141 coz im a cool boy lmao
              child: GestureDetector(
                onTap: () {},
                child:Container(
                    width: double.infinity,
                    color: const Color(0xFF8B8B8B),
                    child: Stack(
                        children: [

                            Positioned(
                                top: 20,
                                right: 20,
                                child: Text(
                                    "Moves: 1",
                                    style: textStyle(
                                        fontSize: 24,
                                        color: Colors.grey.shade900,
                                        fontWeight: FontWeight.w600,
                                    ),
                                ),
                            ),

                            const Center(
                                child: Text(
                                    '15:00',
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 100,
                                        fontWeight: FontWeight.w700,
                                    ),
                                ),
                            ),

                            Positioned(
                                bottom: 30,
                                left: 0,
                                right:0,
                                child:Column(
                                    chilren: const [

                                        Icon(
                                            Icons.tune,
                                            size: 32, 
                                            color: Colors.black,
                                        ),

                                        SizedBox(height: 8),

                                        Text(
                                            "15 min | 10 sec",
                                            style: TextStyle(
                                                fontsize: 24,
                                                color: Colors.black,
                                                fontWeight: FontWeight.w600,
                                            ),

                                        ),

                                    ],

                                ),

                            ),

                        ],

                    ),

                ),

            ),

        ),

        // Control bar attempt

        Container(
            height: 75
            color: const Color(0xFF202020),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [

                    IconButton(
                        onPressed: () {},
                        icon: const Icon(
                            Icons.refresh,
                            color: Colors.white,
                            size: 34,
                        ),
                    ),
                    IconButton(
                        onPressed: () {},
                        icon: cnst Icon(
                            Icons.play_arrow,
                            color: Colors.white,
                            size: 36,
                        ),
                    ),

                    IconButton(
                        onPressed: () {},
                        icon: const Icon(
                            Icons.history,
                            color: Colors.white,
                            size: 34,

                    IconButton(
                        onPressed: () {},
                        icon: const Icon(
                            Icons.volume_up,
                            color: Colors.white,
                            size: 34,
                        ),
                    ),
                ],
            ),
        ),

        //white size now

        Expanded             
        