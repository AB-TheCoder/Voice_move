import React, { useState } from 'react';
import { View, Text, Button, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

export default function App() {
  const [image, setImage] = useState(null);
  const [pgn, setPgn] = useState("");

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      quality: 1,
    });

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setImage(uri);
      sendToBackend(uri);
    }
  };

  const sendToBackend = async (uri) => {
    try {
      const response = await fetch("http://192.168.1.1:8000/extract", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          image_url: uri,
        }),
      });

      const data = await response.json();
      setPgn(data.pgn);
    } catch (error) {
      console.log("Error:", error);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>Tempo</Text>

      <Button title="Upload Scoresheet" onPress={pickImage} />

      {image && (
        <Image
          source={{ uri: image }}
          style={{ width: 200, height: 200, marginTop: 20 }}
        />
      )}

      {pgn !== "" && (
        <Text style={{ marginTop: 20 }}>
          PGN: {pgn}
        </Text>
      )}
    </View>
  );
}