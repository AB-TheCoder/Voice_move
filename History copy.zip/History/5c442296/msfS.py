from PIL import Image, ImageDraw
import math

size = 300
img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

OUTLINE = "#D99B4E"
BODY = "#F3C98A"
AXON_COLOR = "#D99B4E"
MYELIN_COLOR = "#A8DBC5"
MYELIN_OUTLINE = "#6FB897"
TERMINAL_COLOR = "#F2A88A"

def rounded_line(draw, x1, y1, x2, y2, width, color):
    draw.line([x1, y1, x2, y2], fill=color, width=width)
    r = width / 2
    draw.ellipse([x1 - r, y1 - r, x1 + r, y1 + r], fill=color)
    draw.ellipse([x2 - r, y2 - r, x2 + r, y2 + r], fill=color)

# ===== DENDRITES (branching lines top-left of soma) =====
soma_center = (110, 150)
dendrite_angles = [200, 230, 260, 160, 130]
for angle in dendrite_angles:
    rad = math.radians(angle)
    x2 = soma_center[0] + 55 * math.cos(rad)
    y2 = soma_center[1] + 55 * math.sin(rad)
    rounded_line(draw, soma_center[0], soma_center[1], x2, y2, 6, OUTLINE)
    # small sub-branches
    for offset in [-20, 20]:
        rad2 = math.radians(angle + offset)
        x3 = x2 + 20 * math.cos(rad2)
        y3 = y2 + 20 * math.sin(rad2)
        rounded_line(draw, x2, y2, x3, y3, 4, OUTLINE)

# ===== SOMA (cell body) =====
draw.ellipse([70, 115, 150, 185], fill=BODY, outline=OUTLINE, width=5)
# cute face
draw.ellipse([92, 140, 102, 150], fill="#4A2F18")
draw.ellipse([118, 140, 128, 150], fill="#4A2F18")
draw.arc([95, 150, 125, 170], start=20, end=160, fill="#4A2F18", width=3)

# ===== AXON (line extending right from soma) =====
axon_start = (150, 150)
axon_end = (230, 150)
rounded_line(draw, axon_start[0], axon_start[1], axon_end[0], axon_end[1], 6, AXON_COLOR)

# ===== MYELIN SHEATH (segmented ovals along the axon) =====
myelin_positions = [165, 185, 205]
for x in myelin_positions:
    draw.rounded_rectangle([x - 8, 141, x + 8, 159], radius=8, fill=MYELIN_COLOR, outline=MYELIN_OUTLINE, width=3)

# ===== AXON TERMINALS (branching at the end, with round bulbs) =====
terminal_angles = [-30, 0, 30]
for angle in terminal_angles:
    rad = math.radians(angle)
    x2 = axon_end[0] + 30 * math.cos(rad)
    y2 = axon_end[1] + 30 * math.sin(rad)
    rounded_line(draw, axon_end[0], axon_end[1], x2, y2, 5, AXON_COLOR)
    draw.ellipse([x2 - 7, y2 - 7, x2 + 7, y2 + 7], fill=TERMINAL_COLOR, outline=OUTLINE, width=2)

img.save("neuron.png")
print("Saved neuron.png!")