def vihaan():
    user_input = input()  # ← input must be assigned to a variable
    if user_input == "Hello":
        print("Hey There")
    else:
        print("BYEBYE")

vihaan()  # ← Call the function to run it