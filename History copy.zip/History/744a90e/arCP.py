def vihaan():
    user_input = input()
    if user_input == "Hello":
        print("Hey There")
    else:
        print("BYEBYE")