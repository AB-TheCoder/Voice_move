def vihaan():
    user_input = input("Type something: ")
    if user_input == "Hello":
        print("Hey There")
    else:
        print("BYEBYE")

vihaan()