# MicroSkill Exchange — Full Redesign Spec
**Date:** 2026-05-03  
**Theme:** Dark Monochrome (Option A)  
**Output:** Single `index.html` — Tailwind CDN, all styles inline

---

## Section 1 — Design System (Approved)

### Colors
- Background: `#0a0a0a` (body), `#111111` (cards), `#181818` (elevated), `#242424` (floating)
- Text: `#ffffff` (primary), `rgba(255,255,255,0.6)` (secondary), `rgba(255,255,255,0.35)` (muted)
- Borders: `rgba(255,255,255,0.07)` (default), `rgba(255,255,255,0.14)` (hover)
- No hue accent — pure grayscale. Interactive feedback via opacity shift + scale.

### Typography
- Headings: `DM Serif Display` (Google Fonts CDN), letter-spacing `-0.03em`
- Body: `Inter` (Google Fonts CDN), line-height `1.7`
- Scale: hero 64px → section 40px → card 20px → body 15px → label 11px

### Shadows (layered, color-tinted)
```css
--shadow-card: 0 1px 3px rgba(0,0,0,0.4), 0 4px 12px rgba(0,0,0,0.3), 0 0 0 1px rgba(255,255,255,0.05);
--shadow-elevated: 0 2px 6px rgba(0,0,0,0.5), 0 8px 24px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.07);
--shadow-floating: 0 4px 12px rgba(0,0,0,0.6), 0 16px 48px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.1);
```

### Templates → Vanilla JS Mapping
| Template | Where Used | Translation |
|---|---|---|
| `BackgroundPaths` | Landing hero | 36 inline SVG `<path>` with CSS keyframe animations |
| `FallingPattern` | App shell (all screens) | CSS radial-gradient + `@keyframes fall` repeating lines |
| `CanvasRevealEffect` | Login/Register sidebar | Three.js CDN + GLSL dot-matrix WebGL shader |
| `MiniNavbar` | Login/Register top bar | Frosted glass `backdrop-filter: blur(12px)` pill nav |

---

## Section 2 — Components

### Cards
- `background: #111`, `border: 1px solid rgba(255,255,255,0.07)`, `border-radius: 10px`
- Hover: border opacity to 0.14, `transform: translateY(-1px)`, shadow-elevated
- No `transition-all` — only `transform`, `opacity`, `border-color`, `box-shadow`

### Buttons
- **Primary:** `background: #fff`, `color: #000`, pill shape (`border-radius: 999px`), `font-weight: 500`
- **Secondary:** transparent, `border: 1px solid rgba(255,255,255,0.2)`, white text
- **Ghost:** text-only, `color: rgba(255,255,255,0.6)`, hover → white
- All: hover scales `transform: scale(1.02)`, active `scale(0.98)`, focus-visible ring `rgba(255,255,255,0.4)`

### Skill Tags
- Teach: `border: 1px solid rgba(255,255,255,0.15)`, `color: #fff`, `bg: rgba(255,255,255,0.06)`
- Learn: `border: 1px solid rgba(255,255,255,0.07)`, `color: rgba(255,255,255,0.6)`, `bg: transparent`
- Dimensions: `px-2 py-0.5 text-[11px] rounded-sm font-mono`

### Avatars
- Rounded square (6px radius, not circle)
- Monogram initials, font: Inter medium
- Gradient: `linear-gradient(135deg, #2a2a2a, #1a1a1a)`

### Badge Icons (16 SVG geometric icons — no emoji)
| Badge | Icon |
|---|---|
| First Match | shield-check |
| Mentor | users |
| Communicator | message-circle |
| Scholar | book-open |
| Sharer | share-2 |
| Awarded | award |
| Elite | crown |
| Active | zap |
| Quick | lightning-bolt |
| Consistent | calendar-check |
| Star Learner | star |
| Rising | star-half |
| Planner | calendar |
| Layered | layers |
| Trending | trending-up |
| Video Pro | video |

### Bottom Navigation (mobile)
- `backdrop-filter: blur(16px)`, `background: rgba(10,10,10,0.85)`, `border-top: 1px solid rgba(255,255,255,0.07)`
- 5 tabs: Home, Matches, Explore, Chats, Profile
- Active: white icon + white label; inactive: `rgba(255,255,255,0.35)`
- Transitions: `opacity` + `transform` only, spring cubic-bezier `(0.34,1.56,0.64,1)`

---

## Section 3 — Screen Breakdown

### 1. Landing (`screen=landing`)
- Full viewport, `#0a0a0a` bg
- BackgroundPaths: 36 animated SVG curves flowing from left edge, opacity 0.08–0.15
- Hero center: DM Serif Display headline + subline + two CTA buttons (Sign In + Get Started)
- FallingPattern subtle overlay
- No header, no footer — pure hero

### 2. Login (`screen=login`)
- Split layout: left = frosted CanvasRevealEffect WebGL panel, right = form
- MiniNavbar top: "MicroSkill" wordmark pill + Sign Up link
- Form: email + password, sign-in button, divider, "new? register" link
- Supabase `signInWithPassword`

### 3. Register — 4-Step Wizard (`screen=register`)
- Same split layout as login
- Step 1: Name + email + password
- Step 2: Skills to teach (multi-select chips)
- Step 3: Skills to learn (multi-select chips)
- Step 4: Grade + city + profile pic upload
- Progress bar: 4 segments, white fill, animated width

### 4. Dashboard — Main App (`screen=app`)
- FallingPattern shell background (fixed, z-0)
- Top bar: avatar + name + notification bell
- 7 Tabs (frosted glass pill switcher): Home · Matches · Explore · Leaderboard · Challenges · Badges · Chats
- **Home:** feed of recent matches + activity
- **Matches:** list of computed match cards with score bar
- **Explore:** all users grid, search
- **Leaderboard:** ranked list with XP bars
- **Challenges:** active + completed challenges list
- **Badges:** 4×4 SVG badge grid, earned vs locked opacity
- **Chats:** conversation list

### 5. Chat (`screen=chat`)
- Full screen, dark bg
- Top: back arrow + peer avatar + name + video call button
- Messages: right-aligned (own) in `#1f1f1f`, left-aligned (peer) in `#111`
- Supabase Realtime postgres_changes subscription
- Bottom: text input + send button

### 6. Video Call (`screen=videocall`)
- Full screen, pure black
- Remote video fills viewport, local video PiP (bottom-right, 120×90)
- Controls row (center-bottom): mute · video toggle · end call — frosted pill
- WebRTC via Supabase `webrtc_signals` table

### 7. Success (`screen=success`)
- Centered, minimal
- Large checkmark SVG (animated draw)
- "You're all set" headline
- Sub-copy + button to app

---

## Supabase Config
- URL: `https://uiqwredrivcgzruvwuvw.supabase.co`
- Tables: `profiles`, `messages`, `webrtc_signals`, `challenges`, `badges`
- Auth: email/password
- Realtime: messages channel, webrtc_signals channel

---

## Implementation Constraints
- Single `index.html`, all CSS/JS inline
- Tailwind CDN (`https://cdn.tailwindcss.com`)
- Three.js CDN for WebGL
- Google Fonts CDN: DM Serif Display + Inter
- No `transition-all` anywhere
- No default Tailwind blue/indigo
- Mobile-first, responsive
- Spring easing: `cubic-bezier(0.34,1.56,0.64,1)`
