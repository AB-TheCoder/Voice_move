#Print and other Output functions
print("Hello", 5.5, 'Vihaan', end = '\n')
print("Im Back")

#No need to cover other basic topics, Any needed are mentioned below

print("a">"Z")
print(ord("a"), ord("Z"))

print(True or False)