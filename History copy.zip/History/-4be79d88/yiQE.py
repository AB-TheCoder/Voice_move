print("Hello", 5.5, 'Vihaan', end = '\n')
print("Im Back")