from fastapi import FastAPI, File, UploadFile

app = FastAPI()

@app.get("/")
def home():
    return {"status": "ok"}

@app.post("/extract")
async def extract(file: UploadFile = File(...)):
    # dummy response for now
    return {
        "pgn": "1. e4 e5 2. Nf3 Nc6"
    }